/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.jpa;

import java.util.List;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 *
 * @author W208028047
 */
public class Main {

    public static void main(String[] args) {
        ApplicationContext context = new ClassPathXmlApplicationContext(new String[]{"spring-DAO.xml"});

        StudentDAO stdDAO = (StudentDAO) context.getBean("studentDAO");

//        Student student = new Student();
//        student.setFirstname("Gbemisola");
//        student.setLastname("Nogueira");
//        student.setAddress("1600 street");
//        
//        stdDAO.persist(student);
        List<Student> list = stdDAO.getAllStudents();

        for (Student std : list) {
            System.out.println("First Name: " + std.getFirstname());
        }

    }
}
