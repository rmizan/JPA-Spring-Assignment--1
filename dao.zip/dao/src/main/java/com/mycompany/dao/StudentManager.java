/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.dao;

import com.mycompany.jpa.Student;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 *
 * @author W208079293
 */
public class StudentManager {
    public static void main(String[] args) {
        ApplicationContext context = new ClassPathXmlApplicationContext("spring-DAO.xml");
        JdbcDAO dataBase = (JdbcDAO) context.getBean("jdbcDAO");
        System.out.println(dataBase.countOfStudents());
        
        Student std = new Student();
        std.setFirstname("Alexandre");
        std.setLastname("Augusto");
        std.setAddress("Mc Greg st");
        
        dataBase.insertStudent(std);
    }
}
