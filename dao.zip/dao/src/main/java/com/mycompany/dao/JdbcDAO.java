/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.dao;

import com.mycompany.jpa.Student;
import javax.sql.DataSource;
import org.springframework.jdbc.core.JdbcTemplate;

/**
 *
 * @author W208079293
 */
public class JdbcDAO {
    
    private JdbcTemplate jdbcTemplate;

    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }
    

    
    public int countOfStudents(){
        String sql = "select count(*) from student";
        return this.jdbcTemplate.queryForObject(sql, Integer.class);
    }
    

    public void insertStudent(Student std) {
        String sql = "insert into student (firstname, lastname, address) values (?,?,?)";

	jdbcTemplate.update(sql, new Object[] { std.getFirstname(),
		std.getLastname(),std.getAddress()
	});
        
    }
    
}
